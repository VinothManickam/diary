# DiaryBlogAPI

## License
This project is licensed under a private license. All rights reserved. Unauthorized use, reproduction, or distribution of this software is strictly prohibited. Contact the author for more information.

© 2023 Universe

## Description
The application is a simple RESTful API built using Flask, which allows for managing companies and blog posts related to these companies. It authenticates users via JWT tokens and interfaces with MongoDB to store and retrieve data.

## Features
* JWT Authentication: Validates user access with JWT tokens.
* MongoDB Integration: Enables persistent data storage using MongoDB.
* Company Management: Provides endpoints to create and retrieve company details.
* Blog Post Management: Allows creation and retrieval of blog posts for specific companies.
* Privilege Checking: Ensures operations are based on user privileges in the JWT token.
* Structured Error Responses: Offers clear error messages for better user feedback.
* Environment Configuration: Uses dotenv for secure and modular configuration.

## Prerequisites

- Python 3.11+
- Flask
- pymongo
- pyjwt
- dotenv

## Environmental Variables

Before running the app, make sure to set the following environment variables:

1.MONGO_CONNECTION_STRING: Connection string to connect to your MongoDB instance.
2.SECRET_KEY: Secret key used for JWT encoding and decoding.
You can set these directly or use a .env file.

## Installation and Setup
Clone the repository:
```bash
git clone <repository-url>
cd <repository-directory>
```
Install required packages:
```bash
pip install -r requirements.txt
```
Run the application:
```bash
python company.py
```
Your server should start on http://127.0.0.1:5001.

## API Endpoints
* Create Company:

  * URL: /api/companies.
  * Method: POST.
  * Headers: Authorization (Bearer Token).
  * Body: JSON with company as a key.
   
* Get Company Details:

  * URL: /api/companies/<company_name>.
  * Method: GET.
  * Headers: Authorization (Bearer Token).

* Create Blog Post:

  * URL: /api/posts/<company_name>
  * Method: POST
  * Headers: Authorization (Bearer Token)
  * Body: JSON with title and content keys

* Get Blog Posts for a Company:

  * URL: /api/posts/<company_name>
  * Method: GET

## Author
* Vinoth
* Dinesh
